// API Configuration
const API_KEY = 'YOUR_OPENWEATHERMAP_API_KEY'; // Replace with your API key from openweathermap.org
const WEATHER_API = 'https://api.openweathermap.org/data/2.5/weather';
const FORECAST_API = 'https://api.openweathermap.org/data/2.5/forecast';
const GEOCODING_API = 'https://api.openweathermap.org/geo/1.0/direct';
const AQI_API = 'https://api.openweathermap.org/data/2.5/air_pollution';

// DOM Elements
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const locationBtn = document.getElementById('locationBtn');
const themeBtn = document.getElementById('themeBtn');
const mainWeatherCard = document.getElementById('mainWeatherCard');
const loading = document.getElementById('loading');
const error = document.getElementById('error');
const suggestions = document.getElementById('suggestions');

// Application State
const appState = {
    currentWeather: null,
    forecast: null,
    airQuality: null,
    favorites: JSON.parse(localStorage.getItem('weatherFavorites')) || [],
    isDarkMode: localStorage.getItem('darkMode') !== 'false',
};

// Initialize App
function initApp() {
    applyTheme();
    setupEventListeners();
    renderFavorites();
    
    // Load weather for default location or user's current location
    if (appState.favorites.length > 0) {
        loadWeatherByCoords(appState.favorites[0].lat, appState.favorites[0].lon);
    } else {
        getDefaultWeather();
    }
}

// Theme Management
function applyTheme() {
    if (appState.isDarkMode) {
        document.body.classList.remove('light-mode');
        themeBtn.innerHTML = '<i class="fas fa-sun"></i>';
    } else {
        document.body.classList.add('light-mode');
        themeBtn.innerHTML = '<i class="fas fa-moon"></i>';
    }
}

// Event Listeners
function setupEventListeners() {
    searchBtn.addEventListener('click', handleSearch);
    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSearch();
    });
    searchInput.addEventListener('input', handleSuggestions);
    locationBtn.addEventListener('click', getCurrentLocation);
    themeBtn.addEventListener('click', toggleTheme);
}

// Toggle Theme
function toggleTheme() {
    appState.isDarkMode = !appState.isDarkMode;
    localStorage.setItem('darkMode', appState.isDarkMode);
    applyTheme();
}

// Search Functionality
async function handleSearch() {
    const city = searchInput.value.trim();
    if (!city) {
        showError('Please enter a city name');
        return;
    }

    showLoading(true);
    hideError();
    suggestions.classList.remove('show');

    try {
        const coords = await geocodeCity(city);
        if (coords) {
            await loadWeatherByCoords(coords.lat, coords.lon);
            searchInput.value = '';
        } else {
            showError('City not found. Please try again.');
        }
    } catch (err) {
        showError('Failed to fetch weather data. Please try again.');
        console.error(err);
    } finally {
        showLoading(false);
    }
}

// Geocode City
async function geocodeCity(city) {
    try {
        const response = await fetch(
            `${GEOCODING_API}?q=${encodeURIComponent(city)}&limit=1&appid=${API_KEY}`
        );
        if (!response.ok) throw new Error('Geocoding failed');
        
        const data = await response.json();
        if (data.length === 0) return null;
        
        return { lat: data[0].lat, lon: data[0].lon };
    } catch (err) {
        console.error('Geocoding error:', err);
        return null;
    }
}

// Get Suggestions
async function handleSuggestions() {
    const query = searchInput.value.trim();
    if (query.length < 2) {
        suggestions.classList.remove('show');
        return;
    }

    try {
        const response = await fetch(
            `${GEOCODING_API}?q=${encodeURIComponent(query)}&limit=5&appid=${API_KEY}`
        );
        if (!response.ok) throw new Error('Suggestion fetch failed');
        
        const cities = await response.json();
        displaySuggestions(cities);
    } catch (err) {
        console.error('Suggestion error:', err);
    }
}

// Display Suggestions
function displaySuggestions(cities) {
    suggestions.innerHTML = '';
    
    if (cities.length === 0) {
        suggestions.classList.remove('show');
        return;
    }

    cities.forEach((city) => {
        const div = document.createElement('div');
        div.className = 'suggestion-item';
        div.innerHTML = `${city.name}, ${city.country}`;
        div.addEventListener('click', () => {
            searchInput.value = `${city.name}, ${city.country}`;
            loadWeatherByCoords(city.lat, city.lon);
            suggestions.classList.remove('show');
        });
        suggestions.appendChild(div);
    });

    suggestions.classList.add('show');
}

// Get Current Location
function getCurrentLocation() {
    if (!navigator.geolocation) {
        showError('Geolocation is not supported by your browser');
        return;
    }

    showLoading(true);
    hideError();
    locationBtn.disabled = true;
    locationBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';

    navigator.geolocation.getCurrentPosition(
        (position) => {
            const { latitude, longitude } = position.coords;
            loadWeatherByCoords(latitude, longitude);
            locationBtn.disabled = false;
            locationBtn.innerHTML = '<i class="fas fa-location-dot"></i>';
        },
        (err) => {
            showError('Unable to get your location. Please enable location services.');
            console.error('Geolocation error:', err);
            showLoading(false);
            locationBtn.disabled = false;
            locationBtn.innerHTML = '<i class="fas fa-location-dot"></i>';
        }
    );
}

// Load Weather Data
async function loadWeatherByCoords(lat, lon) {
    showLoading(true);
    hideError();

    try {
        const [weather, forecast, airQuality] = await Promise.all([
            fetchWeather(lat, lon),
            fetchForecast(lat, lon),
            fetchAirQuality(lat, lon),
        ]);

        appState.currentWeather = weather;
        appState.forecast = forecast;
        appState.airQuality = airQuality;

        displayWeather(weather);
        displayForecast(forecast);
        displayAirQuality(airQuality);
        updateFavoriteButton();
    } catch (err) {
        showError('Failed to load weather data. Please try again.');
        console.error(err);
    } finally {
        showLoading(false);
    }
}

// Fetch Weather
async function fetchWeather(lat, lon) {
    const response = await fetch(
        `${WEATHER_API}?lat=${lat}&lon=${lon}&units=metric&appid=${API_KEY}`
    );
    if (!response.ok) throw new Error('Weather fetch failed');
    return response.json();
}

// Fetch Forecast
async function fetchForecast(lat, lon) {
    const response = await fetch(
        `${FORECAST_API}?lat=${lat}&lon=${lon}&units=metric&appid=${API_KEY}`
    );
    if (!response.ok) throw new Error('Forecast fetch failed');
    return response.json();
}

// Fetch Air Quality
async function fetchAirQuality(lat, lon) {
    const response = await fetch(
        `${AQI_API}?lat=${lat}&lon=${lon}&appid=${API_KEY}`
    );
    if (!response.ok) throw new Error('Air quality fetch failed');
    return response.json();
}

// Get Default Weather
async function getDefaultWeather() {
    // Default location: New York
    await loadWeatherByCoords(40.7128, -74.0060);
}

// Display Weather
function displayWeather(weather) {
    const { name, sys, main, weather: weatherData, wind, clouds, visibility, coord, dt } = weather;
    
    document.getElementById('cityName').textContent = `${name}, ${sys.country}`;
    document.getElementById('coordinates').textContent = `${coord.lat.toFixed(2)}°, ${coord.lon.toFixed(2)}°`;
    document.getElementById('temperature').textContent = Math.round(main.temp);
    document.getElementById('description').textContent = weatherData[0].description;
    document.getElementById('feelsLike').textContent = `Feels like ${Math.round(main.feels_like)}°`;
    document.getElementById('humidity').textContent = `${main.humidity}%`;
    document.getElementById('windSpeed').textContent = `${wind.speed.toFixed(1)} m/s`;
    document.getElementById('pressure').textContent = `${main.pressure} hPa`;
    document.getElementById('visibility').textContent = `${(visibility / 1000).toFixed(1)} km`;
    document.getElementById('feelsLikeDetail').textContent = `${Math.round(main.feels_like)}°`;
    
    const iconUrl = `https://openweathermap.org/img/wn/${weatherData[0].icon}@4x.png`;
    document.getElementById('weatherIcon').src = iconUrl;
    
    const updateDate = new Date(dt * 1000);
    document.getElementById('updateTime').textContent = `Last updated: ${updateDate.toLocaleString()}`;
    
    // UV Index (estimated based on cloud coverage)
    const uvIndex = Math.max(1, Math.round(10 - (clouds.all / 10)));
    document.getElementById('uvIndex').textContent = uvIndex;
    
    mainWeatherCard.classList.remove('hidden');
}

// Display Forecast
function displayForecast(forecast) {
    const hourlySection = document.getElementById('hourlySection');
    const weeklySection = document.getElementById('weeklySection');
    const hourlyForecast = document.getElementById('hourlyForecast');
    const weeklyForecast = document.getElementById('weeklyForecast');

    // Hourly Forecast
    hourlyForecast.innerHTML = '';
    const hourlyData = forecast.list.slice(0, 8);
    hourlyData.forEach((hour) => {
        const date = new Date(hour.dt * 1000);
        const div = document.createElement('div');
        div.className = 'hourly-card animate-slide-in';
        div.innerHTML = `
            <div class="time">${date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}</div>
            <img src="https://openweathermap.org/img/wn/${hour.weather[0].icon}@2x.png" alt="weather">
            <div class="temp">${Math.round(hour.main.temp)}°</div>
        `;
        hourlyForecast.appendChild(div);
    });
    hourlySection.classList.remove('hidden');

    // Weekly Forecast (5 days at 12:00 PM)
    weeklyForecast.innerHTML = '';
    const weeklyData = forecast.list.filter((item, index) => index % 8 === 0);
    weeklyData.forEach((day) => {
        const date = new Date(day.dt * 1000);
        const div = document.createElement('div');
        div.className = 'weekly-card animate-slide-in';
        div.innerHTML = `
            <div class="day">${date.toLocaleDateString('en-US', { weekday: 'short' })}</div>
            <div class="date">${date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}</div>
            <img src="https://openweathermap.org/img/wn/${day.weather[0].icon}@2x.png" alt="weather">
            <div class="description">${day.weather[0].description}</div>
            <div class="temps">
                <span class="temp-max">${Math.round(day.main.temp_max)}°</span>
                <span class="temp-min">${Math.round(day.main.temp_min)}°</span>
            </div>
        `;
        weeklyForecast.appendChild(div);
    });
    weeklySection.classList.remove('hidden');
}

// Display Air Quality
function displayAirQuality(aqData) {
    const section = document.getElementById('airQualitySection');
    const card = document.getElementById('airQuality');
    
    if (!aqData.list || !aqData.list[0]) return;
    
    const aqi = aqData.list[0].main.aqi;
    const components = aqData.list[0].components;
    
    const aqiLabels = ['Good', 'Fair', 'Moderate', 'Poor', 'Very Poor'];
    const aqiLevel = aqiLabels[aqi - 1] || 'Unknown';
    
    const aqiDescriptions = {
        1: 'Air quality is satisfactory',
        2: 'Air quality is acceptable',
        3: 'Members of sensitive groups may experience health effects',
        4: 'Some members of the general public may begin to experience health effects',
        5: 'Health warnings of emergency conditions',
    };

    card.innerHTML = `
        <div class="aqi-level">${aqiLevel}</div>
        <div class="aqi-score">${aqi}</div>
        <div class="aqi-description">${aqiDescriptions[aqi] || 'No description available'}</div>
        <div class="aqi-details">
            <div class="aqi-item">
                <div class="aqi-item-label">PM2.5</div>
                <div class="aqi-item-value">${(components.pm2_5 || 0).toFixed(1)} µg/m³</div>
            </div>
            <div class="aqi-item">
                <div class="aqi-item-label">PM10</div>
                <div class="aqi-item-value">${(components.pm10 || 0).toFixed(1)} µg/m³</div>
            </div>
            <div class="aqi-item">
                <div class="aqi-item-label">O₃</div>
                <div class="aqi-item-value">${(components.o3 || 0).toFixed(1)} µg/m³</div>
            </div>
            <div class="aqi-item">
                <div class="aqi-item-label">NO₂</div>
                <div class="aqi-item-value">${(components.no2 || 0).toFixed(1)} µg/m³</div>
            </div>
        </div>
    `;
    
    section.classList.remove('hidden');
}

// Favorites Management
function updateFavoriteButton() {
    const btn = document.getElementById('favoriteBtn');
    const isFavorite = appState.favorites.some(
        (fav) => fav.lat === appState.currentWeather.coord.lat && 
                 fav.lon === appState.currentWeather.coord.lon
    );
    
    if (isFavorite) {
        btn.classList.add('active');
        btn.innerHTML = '<i class="fas fa-star"></i>';
    } else {
        btn.classList.remove('active');
        btn.innerHTML = '<i class="far fa-star"></i>';
    }
    
    btn.onclick = toggleFavorite;
}

function toggleFavorite() {
    const { name, sys, coord } = appState.currentWeather;
    const isFavorite = appState.favorites.some(
        (fav) => fav.lat === coord.lat && fav.lon === coord.lon
    );
    
    if (isFavorite) {
        appState.favorites = appState.favorites.filter(
            (fav) => !(fav.lat === coord.lat && fav.lon === coord.lon)
        );
    } else {
        appState.favorites.push({
            name: `${name}, ${sys.country}`,
            lat: coord.lat,
            lon: coord.lon,
        });
    }
    
    localStorage.setItem('weatherFavorites', JSON.stringify(appState.favorites));
    updateFavoriteButton();
    renderFavorites();
}

// Render Favorites
function renderFavorites() {
    const section = document.getElementById('favoritesSection');
    const grid = document.getElementById('favorites');
    
    if (appState.favorites.length === 0) {
        section.classList.add('hidden');
        return;
    }
    
    grid.innerHTML = '';
    appState.favorites.forEach((fav) => {
        const div = document.createElement('div');
        div.className = 'favorite-card';
        div.innerHTML = `
            <div class="fav-name">${fav.name}</div>
            <div class="fav-temp">--°</div>
            <div class="fav-desc">--</div>
            <button class="remove-fav" title="Remove from favorites">✕</button>
        `;
        
        div.addEventListener('click', (e) => {
            if (!e.target.classList.contains('remove-fav')) {
                loadWeatherByCoords(fav.lat, fav.lon);
            }
        });
        
        div.querySelector('.remove-fav').addEventListener('click', (e) => {
            e.stopPropagation();
            appState.favorites = appState.favorites.filter(
                (f) => !(f.lat === fav.lat && f.lon === fav.lon)
            );
            localStorage.setItem('weatherFavorites', JSON.stringify(appState.favorites));
            renderFavorites();
            updateFavoriteButton();
        });
        
        grid.appendChild(div);
        
        // Fetch weather for favorite
        fetchWeather(fav.lat, fav.lon).then((weather) => {
            div.querySelector('.fav-temp').textContent = `${Math.round(weather.main.temp)}°`;
            div.querySelector('.fav-desc').textContent = weather.weather[0].description;
        });
    });
    
    section.classList.remove('hidden');
}

// Error & Loading Handlers
function showError(message) {
    error.textContent = message;
    error.classList.remove('hidden');
}

function hideError() {
    error.classList.add('hidden');
}

function showLoading(isLoading) {
    if (isLoading) {
        loading.classList.remove('hidden');
    } else {
        loading.classList.add('hidden');
    }
}

// Initialize on load
window.addEventListener('DOMContentLoaded', initApp);